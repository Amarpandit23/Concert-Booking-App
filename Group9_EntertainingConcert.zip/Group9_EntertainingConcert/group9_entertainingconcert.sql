-- Create database
CREATE DATABASE group9_entertainingconcert;

USE group9_entertainingconcert;

-- Table structure for table `attendees`
CREATE TABLE `attendees` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ticket_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attendees`
--

INSERT INTO `attendees` (`id`, `ticket_id`, `name`, `email`, `created_at`) VALUES
(3, 3, 'Sam Smith', 'sam@example.com', '2024-12-10 16:32:53'),
(4, 4, 'Alice Jones', 'alice@example.com', '2024-12-10 16:32:53'),
(5, 5, 'Bob Brown', 'bob@example.com', '2024-12-10 16:32:53'),
(6, 42179494, 'John Doe', 'john@example.com', '2024-12-11 15:08:22'),
(995, 4, 'Jane Doe', 'jane@example.com', '2024-12-11 15:08:50');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `event_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `name`, `description`, `event_date`, `created_at`, `updated_at`) VALUES
(2, 'Jazz Festivala', 'Smooth jazz vibes', '2024-11-20', '2024-12-10 16:32:32', '2024-12-10 16:32:32'),
(3, 'Pop Fiesta', 'Pop hits all night', '2025-01-15', '2024-12-10 16:32:32', '2024-12-10 16:32:32'),
(4, 'Classical Evening', 'An elegant classical music performance', '2025-02-10', '2024-12-10 16:32:32', '2024-12-10 16:32:32'),
(5, 'Electronic Dance', 'A night of electrifying dance music', '2025-03-05', '2024-12-10 16:32:32', '2024-12-10 16:32:32'),
(537329, 'Rock Concert', 'A thrilling rock night', '2024-12-12', '2024-12-10 16:32:32', '2024-12-10 16:32:32');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `ticket_type` varchar(255) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `event_id`, `ticket_type`, `price`, `created_at`) VALUES
(1, 3, 'Regular', 40.00, '2024-12-11 15:02:05'),
(3, 2, 'VIP', 120.00, '2024-12-10 16:32:44'),
(4, 2, 'Regular', 70.00, '2024-12-10 16:32:44'),
(5, 3, 'General', 40.00, '2024-12-10 16:32:44'),
(42179494, 537329, 'Regular', 40.00, '2024-12-11 15:07:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendees`
--
ALTER TABLE `attendees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attendees_ticket_id_foreign` (`ticket_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tickets_event_id_foreign` (`event_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=537330;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46143849;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendees`
--
ALTER TABLE `attendees`
  ADD CONSTRAINT `attendees_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
