<?php
include 'db_connect.php'; // Include database connection

// Check if the 'id' parameter exists in the URL
if (isset($_GET['id'])) {
    $ticket_id = htmlspecialchars(trim($_GET['id']));

    // Prepare and execute the DELETE statement
    $query = 'DELETE FROM tickets WHERE id = ?';
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $ticket_id);

    if ($stmt->execute()) {
        echo "<script>alert('Ticket deleted successfully!'); window.location = 'tickets.php';</script>";
    } else {
        echo "<script>alert('Failed to delete ticket. Please try again.'); window.location = 'tickets.php';</script>";
    }
} else {
    echo "<script>alert('No ticket selected for deletion.'); window.location = 'tickets.php';</script>";
}
?>
