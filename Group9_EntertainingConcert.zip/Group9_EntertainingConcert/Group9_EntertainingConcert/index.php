<?php include './includes/header.php'; ?>

<div class="dashboard-layout">
    <?php include './includes/sidebar.php'; ?>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Hero Section -->
        <div class="hero-section">
            <div class="hero-text">
                <h1 class="display-4">Welcome to Entertaining Concert</h1>
                <p class="lead">
                    Get ready for the best concerts and events of the year. Enjoy the music, the vibe, and the
                    atmosphere!
                </p>
                <a href="events.php" class="hero-button">Explore Events</a>
            </div>
        </div>
    </main>
</div>

<?php include './includes/footer.php'; ?>

<!-- Additional Styles for Hero Section and Font Size Control -->
<style>
    /* Hero Section Styles */
    .hero-section {
        height: 80vh;
        color: white;
        display: flex;
        justify-content: center;
        align-items: center;
        text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.7);
        background-color: #333;
    }

    .hero-text {
        text-align: center;
        background: rgba(0, 0, 0, 0.5);
        padding: 30px;
        border-radius: 15px;
    }

    .hero-button {
        margin-top: 20px;
        background-color: #f39c12;
        color: white;
        border: none;
        padding: 10px 30px;
        border-radius: 5px;
        font-size: 16px;
    }

    .hero-button:hover {
        background-color: #e67e22;
    }

    /* Font Size Control Buttons */
    .font-size-controls {
        float: right;
        margin-top: 10px;
    }

    .font-size-controls button {
        background-color: #f39c12;
        color: white;
        border: none;
        padding: 10px;
        border-radius: 5px;
        margin: 5px;
        font-size: 16px;
    }

    .font-size-controls button:hover {
        background-color: #e67e22;
    }
</style>

<!-- Font Size Adjustment Script -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        let zoomLevel = 1; // Default zoom level

        // Function to adjust the zoom level
        function adjustZoom(increase) {
            if (increase) {
                zoomLevel += 10; // Increase zoom by 50%
            } else {
                zoomLevel -= 10; // Decrease zoom by 10%
            }
            document.body.style.zoom = zoomLevel; // Apply the zoom effect
        }

        // Event listeners for the buttons (Make sure the buttons have the right IDs)
        const increaseFontButton = document.getElementById('increase-font');
        const decreaseFontButton = document.getElementById('decrease-font');

        if (increaseFontButton) {
            increaseFontButton.addEventListener('click', function() {
                adjustZoom(true);
            });
        }

        if (decreaseFontButton) {
            decreaseFontButton.addEventListener('click', function() {
                adjustZoom(false);
            });
        }
    });
</script>
