<?php include './includes/header.php'; ?>
<?php include 'db_connect.php'; ?>

<style>
    /* General Layout */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f6f8;
        margin: 0;
        padding: 0;
    }

    .dashboard-layout {
        display: flex;
        flex: 1;
        flex-direction: row-reverse;
    }

    /* Sidebar */
    .dashboard-layout .sidebar {
        background-color: #007a62;
        color: #fff;
    }

    /* Main Content */
    .main-content {
        background-color: #fff;
        padding: 30px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        margin: 20px;
    }

    .main-content h2 {
        margin-top: 0;
        font-size: 1.8em;
        color: #34495e;
    }

    .add-ticket-btn {
        display: inline-block;
        padding: 10px 20px;
        background-color: #1abc9c;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        font-weight: bold;
        margin-bottom: 20px;
    }

    .add-ticket-btn:hover {
        background-color: #16a085;
    }

    /* Table Styling */
    .tickets-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .tickets-table th,
    .tickets-table td {
        padding: 15px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .tickets-table th {
        background-color: #f8f9fa;
        font-weight: bold;
    }

    .tickets-table tbody tr:hover {
        background-color: #f1f1f1;
    }

    .tickets-table .edit-btn,
    .tickets-table .delete-btn {
        text-decoration: none;
        padding: 8px 15px;
        border-radius: 4px;
        color: #fff;
        transition: background-color 0.3s ease;
    }

    .tickets-table .edit-btn {
        background-color: #3498db;
    }

    .tickets-table .edit-btn:hover {
        background-color: #2980b9;
    }

    .tickets-table .delete-btn {
        background-color: #e74c3c;
    }

    .tickets-table .delete-btn:hover {
        background-color: #c0392b;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .dashboard-layout {
            flex-direction: column;
        }

        .main-content {
            margin: 10px;
            padding: 20px;
        }
    }
</style>

<div class="dashboard-layout">
    <?php include './includes/sidebar.php'; ?>

    <?php
    $query = "SELECT v.id, c.name AS event_name, v.ticket_type, v.price, v.created_at 
                  FROM tickets v 
                  JOIN events c ON v.event_id = c.id 
                  ORDER BY v.created_at DESC";
    $result = mysqli_query($conn, $query);
    
    if (!$result) {
        die('Query failed: ' . mysqli_error($conn));
    }
    ?>

    <main class="main-content">
        <h2>Tickets</h2>
        <a href="add_ticket.php" class="add-ticket-btn">Add New Ticket</a>
        <table class="tickets-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Event</th>
                    <th>Ticket Type</th>
                    <th>Price</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $counter = 1; // Initialize counter
                while ($ticket = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= $counter++ ?></td>
                    <td><?= htmlspecialchars($ticket['event_name']) ?></td>
                    <td><?= htmlspecialchars($ticket['ticket_type']) ?></td>
                    <td><?= htmlspecialchars(number_format($ticket['price'], 2)) ?></td>
                    <td><?= htmlspecialchars($ticket['created_at']) ?></td>
                    <td>
                        <a href="edit_ticket.php?id=<?= htmlspecialchars($ticket['id']) ?>" class="edit-btn">Edit</a>
                        <a href="delete_ticket.php?id=<?= htmlspecialchars($ticket['id']) ?>"
                            class="delete-btn">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
</div>

<?php include './includes/footer.php'; ?>
