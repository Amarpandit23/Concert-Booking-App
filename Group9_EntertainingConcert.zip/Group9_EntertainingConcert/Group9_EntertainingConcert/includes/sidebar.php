<!-- Sidebar -->
<aside class="sidebar">
    <ul class="sidebar-menu">
        <li>
            <a href="index.php" class="<?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>">Home</a>
        </li>
        <li>
            <a href="events.php" class="<?= basename($_SERVER['PHP_SELF']) == 'events.php' ? 'active' : '' ?>">Event</a>
        </li>
        <li>
            <a href="tickets.php"
                class="<?= basename($_SERVER['PHP_SELF']) == 'tickets.php' ? 'active' : '' ?>">Tickets</a>
        </li>
        <li>
            <a href="attendees.php"
                class="<?= basename($_SERVER['PHP_SELF']) == 'attendees.php' ? 'active' : '' ?>">Attendee</a>
        </li>
    </ul>
</aside>
