<?php $logo_path = './assets/logo.png'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <!-- Bootstrap CSS for styling (if needed) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* General body font size */
        body {
            font-size: 16px;
        }

        /* Header styles */
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .header-title {
            font-size: 2rem;
            margin: 0;
        }

        .header-logo {
            height: 50px;
            /* Set the height of the logo */
            margin-right: 20px;
            /* Space between the logo and the title */
        }

        /* Font size control buttons */
        .font-size-buttons {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        .font-size-buttons button {
            padding: 8px 12px;
            font-size: 1.1rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .font-size-buttons button:hover {
            background-color: #ddd;
        }
    </style>
</head>

<body>
    <!-- Header -->
    <header class="header">
        <div class="header-container">
            <!-- Logo -->
            <img src="<?php echo $logo_path; ?>" alt="Logo" class="header-logo">
            <h1 class="header-title">Entertaining Concert</h1>
            <div class="header-user">
                <span>
                    <button class="btn btn-primary" id="increaseZoom" onclick="changeFontSize(1)">A+</button>
                    <button class="btn btn-secondary" id="decreaseZoom" onclick="changeFontSize(-1)">A-</button>
                </span>
            </div>
        </div>
    </header>

    <script>
        // Change font size for the entire page
        function changeFontSize(factor) {
            let body = document.body;
            let currentSize = window.getComputedStyle(body).fontSize;
            let newSize = parseFloat(currentSize) + factor;

            if (newSize >= 10 && newSize <= 30) { // Min size 10px, max size 30px
                body.style.fontSize = newSize + 'px';
            }
        }

        // For keyboard shortcut handling: (Ctrl + "+" and Ctrl + "-")
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === '+') {
                changeFontSize(1); // Increase font size
            } else if (e.ctrlKey && e.key === '-') {
                changeFontSize(-1); // Decrease font size
            }
        });
    </script>
</body>

</html>
