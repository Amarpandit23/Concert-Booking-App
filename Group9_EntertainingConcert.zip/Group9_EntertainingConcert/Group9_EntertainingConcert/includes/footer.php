  <!-- Footer -->
  <footer class="footer">
    <ul class="contributors">
      <li>Harpreet Kaur - 8997768</li>
      <li>Nidhi Khokhar - 9001199</li>
      <li>Harmanpreet Singh - 8998599</li>
    </ul>
  </footer>
</body>
</html>
