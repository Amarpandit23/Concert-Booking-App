<?php
include './includes/header.php';
include 'db_connect.php';

$query = "SELECT r.id, r.ticket_id, v.ticket_type, r.name, r.email, r.created_at 
          FROM attendees r 
          JOIN tickets v ON v.id = r.ticket_id 
          ORDER BY r.created_at DESC";
$result = mysqli_query($conn, $query);
?>

<style>
    /* General Layout */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f6f8;
        margin: 0;
        padding: 0;
    }

    .dashboard-layout {
        display: flex;
        flex: 1;
        flex-direction: row-reverse;
    }

    /* Sidebar */
    .dashboard-layout .sidebar {
        background-color: #007a62;
        color: #fff;
    }

    /* Main Content */
    .main-content {
        background-color: #fff;
        padding: 30px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        margin: 20px;
    }

    .main-content h2 {
        margin-top: 0;
        font-size: 1.8em;
        color: #34495e;
    }

    .add-customer-btn {
        display: inline-block;
        padding: 10px 20px;
        background-color: #1abc9c;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        font-weight: bold;
        margin-bottom: 20px;
    }

    .add-customer-btn:hover {
        background-color: #16a085;
    }

    /* Table Styling */
    .customers-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .customers-table th,
    .customers-table td {
        padding: 15px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .customers-table th {
        background-color: #f8f9fa;
        font-weight: bold;
    }

    .customers-table tbody tr:hover {
        background-color: #f1f1f1;
    }

    .customers-table .edit-btn,
    .customers-table .delete-btn {
        text-decoration: none;
        padding: 8px 15px;
        border-radius: 4px;
        color: #fff;
        transition: background-color 0.3s ease;
    }

    .customers-table .edit-btn {
        background-color: #3498db;
    }

    .customers-table .edit-btn:hover {
        background-color: #2980b9;
    }

    .customers-table .delete-btn {
        background-color: #e74c3c;
    }

    .customers-table .delete-btn:hover {
        background-color: #c0392b;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .dashboard-layout {
            grid-template-columns: 1fr;
        }

        .main-content {
            margin: 10px;
            padding: 20px;
        }
    }
</style>

<div class="dashboard-layout">
    <?php include './includes/sidebar.php'; ?>
    <main class="main-content">
        <h2>Attendees</h2>
        <a href="add_attendee.php" class="add-customer-btn">Add New Attendee</a>
        <table class="customers-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Ticket Type</th>
                    <th>Created Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $counter = 1; ?>
                <?php while ($attendee = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= $counter++ ?></td>
                    <td><?= htmlspecialchars($attendee['name']) ?></td>
                    <td><?= htmlspecialchars($attendee['email']) ?></td>
                    <td><?= htmlspecialchars($attendee['ticket_type']) ?></td>
                    <td><?= htmlspecialchars($attendee['created_at']) ?></td>
                    <td>
                        <a href="edit_attendee.php?id=<?= htmlspecialchars($attendee['id']) ?>" class="edit-btn">Edit</a>
                        <a href="generate_invoice.php?id=<?= htmlspecialchars($attendee['id']) ?>" target="_blank"
                            class="invoice-btn">Invoice</a>
                        <a href="delete_attendee.php?id=<?= htmlspecialchars($attendee['id']) ?>" class="delete-btn"
                            onclick="return confirm('Are you sure you want to delete this attendee?');">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
</div>

<?php include './includes/footer.php'; ?>
