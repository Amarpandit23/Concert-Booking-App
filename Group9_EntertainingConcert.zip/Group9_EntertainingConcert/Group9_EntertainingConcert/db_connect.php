<?php
// Database connection
$host = 'localhost';
$dbname = 'group9_entertainingconcert';
$user = 'root';
$password = '';

$conn = mysqli_connect($host, $user, $password, $dbname);

// Check connection
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}
