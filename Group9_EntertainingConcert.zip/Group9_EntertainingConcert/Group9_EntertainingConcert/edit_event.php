<?php
include './includes/header.php';
include 'db_connect.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Sanitize input
    $query = 'SELECT * FROM events WHERE id = ?';
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $event = $result->fetch_assoc();

    if (!$event) {
        echo "<script>alert('Event not found!'); window.location = 'events.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('Invalid event ID!'); window.location = 'events.php';</script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars(trim($_POST['name']));
    $description = htmlspecialchars(trim($_POST['description']));
    $event_date = htmlspecialchars(trim($_POST['event_date']));

    $update_query = 'UPDATE events SET name = ?, description = ?, event_date = ? WHERE id = ?';
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param('sssi', $name, $description, $event_date, $id);

    if ($stmt->execute()) {
        echo "<script>alert('Event updated successfully!'); window.location = 'events.php';</script>";
    } else {
        echo "<script>alert('Failed to update event. Please try again.');</script>";
    }
}
?>
<style>
    .dashboard-layout {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
    }

    .main-content {
        flex: 1;
        background-color: #fff;
        padding: 30px;
        margin: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .main-content h2 {
        margin-top: 0;
        font-size: 1.8em;
        color: #34495e;
    }

    .event-form {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .event-form label {
        font-weight: bold;
        color: #2c3e50;
    }

    .event-form input,
    .event-form textarea,
    .event-form button {
        font-size: 1em;
        padding: 10px;
        border-radius: 4px;
        border: 1px solid #ddd;
    }

    .event-form textarea {
        resize: none;
        height: 100px;
    }

    .event-form button {
        background-color: #1abc9c;
        color: #fff;
        border: none;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .event-form button:hover {
        background-color: #16a085;
    }

    @media (max-width: 768px) {
        .main-content {
            margin: 10px;
            padding: 20px;
        }
    }
</style>
<div class="dashboard-layout">
    <?php include './includes/sidebar.php'; ?>
    <main class="main-content">
        <h2>Edit Event</h2>
        <form method="POST" action="edit_event.php?id=<?= htmlspecialchars($id) ?>" class="event-form">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" value="<?= htmlspecialchars($event['name']) ?>" required>

            <label for="description">Description</label>
            <textarea id="description" name="description" required><?= htmlspecialchars($event['description']) ?></textarea>

            <label for="event_date">Event Date</label>
            <input type="date" id="event_date" name="event_date"
                value="<?= htmlspecialchars($event['event_date']) ?>" required>

            <button type="submit" class="submit-btn">Update Event</button>
        </form>
    </main>
</div>

<?php include './includes/footer.php'; ?>
