<?php
include './includes/header.php';
include './utils.php'; // Ensure this file has the generateUUID() function.
include 'db_connect.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $id = generateUUID();
    $event_id = htmlspecialchars(trim($_POST['event_id']));
    $ticket_type = htmlspecialchars(trim($_POST['ticket_type']));
    $price = htmlspecialchars(trim($_POST['price']));

    // Use prepared statements to avoid SQL injection
    $query = 'INSERT INTO tickets (id, event_id, ticket_type, price) VALUES (?, ?, ?, ?)';
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssss', $id, $event_id, $ticket_type, $price);

    if ($stmt->execute()) {
        echo "<script>alert('Ticket added successfully!'); window.location = 'tickets.php';</script>";
    } else {
        echo "<script>alert('Failed to add ticket. Please try again.');</script>";
    }
}

$events_query = 'SELECT * FROM events ORDER BY name';
$events_result = mysqli_query($conn, $events_query);
?>

<div class="dashboard-layout">
    <?php include './includes/sidebar.php'; ?>
    <main class="main-content">
        <h2>Add New Ticket</h2>
        <form method="POST" action="add_ticket.php" class="ticket-form">
            <label for="event_id">Event</label>
            <select id="event_id" name="event_id" required>
                <option value="">Select Event</option>
                <?php while ($event = mysqli_fetch_assoc($events_result)): ?>
                <option value="<?= htmlspecialchars($event['id']) ?>">
                    <?= htmlspecialchars($event['name']) ?>
                </option>
                <?php endwhile; ?>
            </select>

            <label for="ticket_type">Ticket Type</label>
            <input type="text" id="ticket_type" name="ticket_type" placeholder="Enter ticket type" required>

            <label for="price">Price</label>
            <input type="text" id="price" name="price" placeholder="Enter ticket price" required>

            <button type="submit" class="submit-btn">Add Ticket</button>
        </form>
    </main>
</div>

<style>
    .dashboard-layout {
        display: flex;
        gap: 20px;
        padding: 20px;
    }

    .main-content {
        flex: 1;
        background-color: #fff;
        padding: 30px;
        margin: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .main-content h2 {
        font-size: 1.8em;
        color: #34495e;
    }

    .ticket-form {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .ticket-form label {
        font-weight: bold;
        color: #2c3e50;
    }

    .ticket-form select,
    .ticket-form input,
    .ticket-form button {
        font-size: 1em;
        padding: 10px;
        border-radius: 4px;
        border: 1px solid #ddd;
    }

    .ticket-form select {
        background-color: #f9f9f9;
    }

    .ticket-form button {
        background-color: #1abc9c;
        color: #fff;
        border: none;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .ticket-form button:hover {
        background-color: #16a085;
    }

    @media (max-width: 768px) {
        .dashboard-layout {
            flex-direction: column;
        }
    }
</style>

<?php include './includes/footer.php'; ?>
