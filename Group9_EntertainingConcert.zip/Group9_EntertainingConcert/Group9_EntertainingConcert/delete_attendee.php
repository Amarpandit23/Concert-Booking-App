<?php
include './includes/header.php';
include 'db_connect.php';

// Check if 'id' is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare('DELETE FROM attendees WHERE id = ?');
    $stmt->bind_param('s', $id);

    if ($stmt->execute()) {
        // Redirect back to attendees page
        header('Location: attendees.php?message=Attendee+deleted+successfully');
        exit();
    } else {
        echo 'Error deleting attendee: ' . $stmt->error;
    }
    $stmt->close();
} else {
    echo 'Invalid request.';
}
?>
