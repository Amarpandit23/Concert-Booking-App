<?php
include 'db_connect.php'; // Include database connection

if (isset($_GET['id'])) {
    $event_id = intval($_GET['id']); // Sanitize input

    // SQL query to delete the event
    $query = "DELETE FROM events WHERE id = $event_id";

    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "<script>alert('Event deleted successfully!'); window.location = 'events.php';</script>";
    } else {
        echo "<script>alert('Failed to add event. Please try again.');</script>";
    }
} else {
    echo "<script>alert('Failed to add event. Please try again.');</script>";
}

exit();
?>
