<?php
require './fpdf/fpdf.php';
include 'db_connect.php';

if (isset($_GET['id'])) {
    $attendee_id = $_GET['id'];

    // Fetch attendee details
    $attendee_query = "SELECT r.id, r.name, r.email, r.created_at, 
                              v.ticket_type, v.price, 
                              e.name AS event_name, e.description, e.event_date 
                       FROM attendees r
                       JOIN tickets v ON r.ticket_id = v.id
                       JOIN events e ON v.event_id = e.id
                       WHERE r.id = '$attendee_id'";
    $attendee_result = mysqli_query($conn, $attendee_query);
    $attendee = mysqli_fetch_assoc($attendee_result);

    if (!$attendee) {
        die('Attendee not found.');
    }
} else {
    die('Attendee ID not provided.');
}

// Business details
$business_name = 'Entertaining Concert Inc.';
$business_address = '123 Main St, Kitchener, Canada';
$logo_path = './assets/logo.png';

// Initialize FPDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Business Logo and Details
if (file_exists($logo_path)) {
    $logo_width = 50;
    $pdf->Image($logo_path, ($pdf->GetPageWidth() - $logo_width) / 2, 10, $logo_width);
}

$pdf->Ln(40);
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 30, $business_name, 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, $business_address, 0, 1, 'C');
$pdf->Ln(10);

// Title
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Invoice', 0, 1, 'C');
$pdf->Ln(10);

// Attendee and Ticket Information
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(95, 10, 'Attendee Information', 1, 0, 'L');
$pdf->Cell(95, 10, 'Event Information', 1, 1, 'L');

$pdf->SetFont('Arial', '', 12);
$pdf->Cell(95, 10, 'Name: ' . $attendee['name'], 1, 0);
$pdf->Cell(95, 10, 'Event: ' . $attendee['event_name'], 1, 1);

$pdf->Cell(95, 10, 'Email: ' . $attendee['email'], 1, 0);
$pdf->Cell(95, 10, 'Date: ' . $attendee['event_date'], 1, 1);

$pdf->Ln(10);

// Ticket Details
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(190, 10, 'Ticket Details', 1, 1, 'C');

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(95, 10, 'Ticket Type', 1, 0, 'C');
$pdf->Cell(95, 10, 'Price', 1, 1, 'C');

$pdf->SetFont('Arial', '', 12);
$pdf->Cell(95, 10, $attendee['ticket_type'], 1, 0);
$pdf->Cell(95, 10, '$' . number_format($attendee['price'], 2), 1, 1);

$pdf->Ln(10);

// Total Cost
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(140, 10, 'Total:', 0, 0, 'R');
$pdf->Cell(50, 10, '$' . number_format($attendee['price'], 2), 1, 1, 'C');

// Output PDF
$pdf->Output('I', 'Invoice_' . $attendee['id'] . '.pdf');
?>
