<?php
include './includes/header.php';
include './utils.php';
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = generateUUID();
    $ticket_id = $_POST['ticket_id'];
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));

    $query = "INSERT INTO attendees (id, ticket_id, name, email) 
              VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssss', $id, $ticket_id, $name, $email);
    $stmt->execute();

    header('Location: attendees.php');
    exit();
}

$tickets_query = "SELECT v.id, v.event_id, v.ticket_type, c.name
                  FROM tickets v 
                  JOIN events c ON v.event_id = c.id 
                  ORDER BY v.created_at DESC";
$tickets_result = mysqli_query($conn, $tickets_query);
?>

<div class="dashboard-layout">
    <?php include './includes/sidebar.php'; ?>
    <main class="main-content">
        <h2>Add New Attendee</h2>
        <form method="POST" action="add_attendee.php" class="ticket-form">
            <label for="ticket_id">Ticket</label>
            <select id="ticket_id" name="ticket_id" required>
                <?php while ($ticket = mysqli_fetch_assoc($tickets_result)): ?>
                <option value="<?= htmlspecialchars($ticket['id']) ?>">
                    <?= htmlspecialchars($ticket['ticket_type'] . ' ( ' . $ticket['name'] . ' )') ?>
                </option>
                <?php endwhile; ?>
            </select>

            <label for="name">Name</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <button type="submit" class="submit-btn">Add Attendee</button>
        </form>
    </main>
</div>

<?php include './includes/footer.php'; ?>

<style>
    .dashboard-layout {
        display: flex;
        gap: 20px;
        padding: 20px;
    }

    .main-content {
        flex: 1;
        background-color: #fff;
        padding: 30px;
        margin: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .main-content h2 {
        font-size: 1.8em;
        color: #34495e;
    }

    .ticket-form {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .ticket-form label {
        font-weight: bold;
        color: #2c3e50;
    }

    .ticket-form input,
    .ticket-form select,
    .ticket-form button {
        font-size: 1em;
        padding: 10px;
        border-radius: 4px;
        border: 1px solid #ddd;
    }

    .ticket-form button {
        background-color: #1abc9c;
        color: #fff;
        border: none;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .ticket-form button:hover {
        background-color: #16a085;
    }

    @media (max-width: 768px) {
        .dashboard-layout {
            flex-direction: column;
        }
    }
</style>
