<?php include './includes/header.php'; ?>
<?php include 'db_connect.php'; ?>
<style>
    /* General Layout */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f6f8;
        margin: 0;
        padding: 0;
    }

    .dashboard-layout {
        display: flex;
        flex: 1;
        flex-direction: row-reverse;
    }

    /* Sidebar */
    .dashboard-layout .sidebar {
        background-color: #007a62;
        color: #fff;
    }

    /* Main Content */
    .main-content {
        background-color: #fff;
        padding: 30px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        margin: 20px;
    }

    .main-content h2 {
        margin-top: 0;
        font-size: 1.8em;
        color: #34495e;
    }

    .add-event-btn {
        display: inline-block;
        padding: 10px 20px;
        background-color: #1abc9c;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        font-weight: bold;
        margin-bottom: 20px;
    }

    .add-event-btn:hover {
        background-color: #16a085;
    }

    /* Table Styling */
    .events-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .events-table th,
    .events-table td {
        padding: 15px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .events-table th {
        background-color: #f8f9fa;
        font-weight: bold;
    }

    .events-table tbody tr:hover {
        background-color: #f1f1f1;
    }

    .events-table .edit-btn,
    .events-table .delete-btn {
        text-decoration: none;
        padding: 8px 15px;
        border-radius: 4px;
        color: #fff;
        transition: background-color 0.3s ease;
    }

    .events-table .edit-btn {
        background-color: #3498db;
    }

    .events-table .edit-btn:hover {
        background-color: #2980b9;
    }

    .events-table .delete-btn {
        background-color: #e74c3c;
    }

    .events-table .delete-btn:hover {
        background-color: #c0392b;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .dashboard-layout {
            grid-template-columns: 1fr;
        }

        .main-content {
            margin: 10px;
            padding: 20px;
        }
    }
</style>
<div class="dashboard-layout">
    <?php include './includes/sidebar.php'; ?>

    <?php
    $query = 'SELECT * FROM events ORDER BY created_at DESC';
    $result = mysqli_query($conn, $query);
    
    if (!$result) {
        die('Query failed: ' . mysqli_error($conn));
    }
    ?>

    <main class="main-content">
        <h2>Events</h2>
        <a href="add_event.php" class="add-event-btn">Add New Event</a>
        <table class="events-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Event Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php 
      $counter = 1; // Initialize counter
      while ($event = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= $counter++ ?></td>
                    <td><?= htmlspecialchars($event['name']) ?></td>
                    <td><?= htmlspecialchars($event['description']) ?></td>
                    <td><?= htmlspecialchars($event['event_date']) ?></td>
                    <td>
                        <a href="edit_event.php?id=<?= htmlspecialchars($event['id']) ?>" class="edit-btn">Edit</a>
                        <a href="delete_event.php?id=<?= htmlspecialchars($event['id']) ?>" class="delete-btn">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
</div>

<?php include './includes/footer.php'; ?>
