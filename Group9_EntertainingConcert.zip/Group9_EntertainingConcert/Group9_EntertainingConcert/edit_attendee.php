<?php
include './includes/header.php';
include 'db_connect.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM attendees WHERE id = '$id'";
    $result = mysqli_query($conn, $query);
    $attendee = mysqli_fetch_assoc($result);

    if (!$attendee) {
        header('Location: attendees.php');
        exit();
    }
} else {
    header('Location: attendees.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));

    // Use prepared statements to avoid SQL injection
    $update_query = "UPDATE attendees 
                     SET name = ?, email = ? 
                     WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param('sss', $name, $email, $id);
    $stmt->execute();

    header('Location: attendees.php');
    exit();
}
?>

<div class="dashboard-layout">
    <?php include './includes/sidebar.php'; ?>
    <main class="main-content">
        <h2>Edit Attendee</h2>
        <form method="POST" action="edit_attendee.php?id=<?= htmlspecialchars($id) ?>" class="ticket-form">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" value="<?= htmlspecialchars($attendee['name']) ?>" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?= htmlspecialchars($attendee['email']) ?>"
                required>

            <button type="submit" class="submit-btn">Update Attendee</button>
        </form>
    </main>
</div>

<?php include './includes/footer.php'; ?>

<style>
    .dashboard-layout {
        display: flex;
        gap: 20px;
        padding: 20px;
    }

    .main-content {
        flex: 1;
        background-color: #fff;
        padding: 30px;
        margin: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .main-content h2 {
        font-size: 1.8em;
        color: #34495e;
    }

    .ticket-form {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .ticket-form label {
        font-weight: bold;
        color: #2c3e50;
    }

    .ticket-form input,
    .ticket-form button {
        font-size: 1em;
        padding: 10px;
        border-radius: 4px;
        border: 1px solid #ddd;
    }

    .ticket-form button {
        background-color: #1abc9c;
        color: #fff;
        border: none;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .ticket-form button:hover {
        background-color: #16a085;
    }

    @media (max-width: 768px) {
        .dashboard-layout {
            flex-direction: column;
        }
    }
</style>
